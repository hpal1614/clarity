"""
Base Sidekick Abstract Class

This module defines the abstract base class that all Sidekicks must inherit from.
It provides the standard interface and common functionality that ensures
consistent behavior across all 10 Sidekicks in the Clarity platform.

Each Sidekick specializes in a specific type of prompt generation, but all
follow the same patterns for initialization, task handling, and LLM integration.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from langchain.prompts import PromptTemplate
import logging

logger = logging.getLogger(__name__)

class BaseSidekick(ABC):
    """
    Abstract base class for all Sidekick implementations.
    
    This class defines the interface that all Sidekicks must implement
    to ensure consistent behavior and integration with the Sidekick Engine.
    
    Key Responsibilities:
    - Define the standard Sidekick interface
    - Provide common functionality for all Sidekicks
    - Ensure consistent error handling and logging
    - Manage LangChain integration patterns
    
    Integration Points:
    - Used by: SidekickEngine for routing and execution
    - Extended by: All 10 Sidekick implementations
    - Interacts with: LangChainManager for LLM calls
    - Returns: PromptTemplate objects for the Controller
    """
    
    def __init__(self, name: str, version: str, display_name: str):
        """
        Initialize the base Sidekick with common attributes.
        
        Args:
            name: Unique identifier for the Sidekick (e.g., "fixxy")
            version: Version string (e.g., "v1.0")
            display_name: Human-readable name (e.g., "Fixxy - Data Cleanup Specialist")
        """
        
        self.name = name.lower()
        self.version = version
        self.display_name = display_name
        
        # Common attributes
        self._enabled = True
        self._requires_llm = False  # Subclasses can override
        self._supported_tasks = []  # Subclasses must populate
        
        # Statistics tracking
        self._stats = {
            "requests_handled": 0,
            "successful_generations": 0,
            "failed_generations": 0,
            "llm_calls_made": 0,
            "cache_hits": 0
        }
        
        # Initialize LangChain components
        self._initialize_langchain_components()
        
        logger.info(f"Initialized {self.display_name} version {self.version}")
    
    @abstractmethod
    def _initialize_langchain_components(self):
        """
        Initialize LangChain-specific components for this Sidekick.
        
        This method should set up:
        - Prompt templates
        - LLM chains
        - Output parsers
        - Any other LangChain components
        
        Must be implemented by each Sidekick.
        """
        pass
    
    @abstractmethod
    def get_supported_tasks(self) -> List[str]:
        """
        Return list of task types this Sidekick can handle.
        
        Returns:
            List[str]: Task type identifiers (e.g., ["deduplicate", "validate"])
        """
        pass
    
    @abstractmethod
    def create_prompt_template(self, task_type: str, job_context: Dict[str, Any]) -> PromptTemplate:
        """
        Create a LangChain PromptTemplate for the specified task.
        
        This is the main method that generates task-specific prompts.
        Each Sidekick implements this differently based on its specialty.
        
        Args:
            task_type: The specific task to create a prompt for
            job_context: Context information including data schema, rules, etc.
            
        Returns:
            PromptTemplate: LangChain template ready for use
            
        Raises:
            ValueError: If task_type is not supported
            Exception: For any generation failures
        """
        pass
    
    def get_version(self) -> str:
        """Get the Sidekick version."""
        return self.version
    
    def is_enabled(self) -> bool:
        """Check if this Sidekick is enabled."""
        return self._enabled
    
    def requires_llm(self) -> bool:
        """Check if this Sidekick requires LLM assistance."""
        return self._requires_llm
    
    def can_handle_task(self, task_type: str) -> bool:
        """
        Check if this Sidekick can handle the specified task type.
        
        Args:
            task_type: Task type to check
            
        Returns:
            bool: True if this Sidekick supports the task
        """
        return task_type in self.get_supported_tasks()
    
    def generate_prompt(self, task_type: str, context: Dict[str, Any], 
                       langchain_manager: Any, job_id: str) -> Dict[str, Any]:
        """
        Generate a prompt for the specified task with full error handling.
        
        This method wraps create_prompt_template with additional logic for:
        - Error handling and fallbacks
        - LLM integration when needed
        - Statistics tracking
        - Caching (if implemented)
        
        Args:
            task_type: Task to generate prompt for
            context: Job context and parameters
            langchain_manager: Manager for LLM calls
            job_id: Job ID for logging
            
        Returns:
            Dict containing prompt and metadata
        """
        
        self._stats["requests_handled"] += 1
        
        try:
            logger.info(f"[{job_id}] {self.name} generating prompt for task '{task_type}'")
            
            # Check if task is supported
            if not self.can_handle_task(task_type):
                raise ValueError(f"Task type '{task_type}' not supported by {self.name}")
            
            # Determine generation method
            if self._should_use_llm(task_type, context):
                generation_method = "llm_assisted"
                llm_used = True
            else:
                generation_method = "template"
                llm_used = False
            
            # Generate the prompt template
            try:
                prompt_template = self.create_prompt_template(task_type, context)
                
                # Validate the template
                if not isinstance(prompt_template, PromptTemplate):
                    raise TypeError("create_prompt_template must return a PromptTemplate")
                
                # Extract template information
                template_content = prompt_template.template
                input_variables = prompt_template.input_variables
                
            except Exception as e:
                logger.error(f"[{job_id}] Primary generation failed: {str(e)}")
                
                # Try LLM-assisted generation if not already attempted
                if not llm_used and self._requires_llm and langchain_manager:
                    logger.info(f"[{job_id}] Attempting LLM-assisted generation")
                    llm_result = self._generate_with_llm(task_type, context, langchain_manager, job_id)
                    template_content = llm_result.get("llm_content", "")
                    input_variables = ["data_context"]  # Default
                    generation_method = "llm_fallback"
                    llm_used = True
                else:
                    raise
            
            # Prepare the result
            result = {
                "prompt_text": template_content,
                "input_variables": input_variables,
                "expected_output": self._get_expected_output(task_type),
                "model_preference": self._get_model_preference(task_type),
                "max_tokens": self._get_max_tokens(task_type),
                "temperature": self._get_temperature(task_type),
                "method": generation_method,
                "llm_used": llm_used,
                "metadata": {
                    "sidekick": self.name,
                    "version": self.version,
                    "task_type": task_type
                }
            }
            
            self._stats["successful_generations"] += 1
            if llm_used:
                self._stats["llm_calls_made"] += 1
            
            logger.info(f"[{job_id}] Prompt generated successfully using {generation_method} method")
            return result
            
        except Exception as e:
            self._stats["failed_generations"] += 1
            logger.error(f"[{job_id}] Prompt generation failed: {str(e)}", exc_info=True)
            
            # Try fallback generation
            fallback_result = self.generate_fallback_prompt(task_type, context)
            if fallback_result:
                fallback_result["method"] = "fallback"
                return fallback_result
            
            raise
    
    def generate_fallback_prompt(self, task_type: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Generate a fallback prompt when primary generation fails.
        
        This provides graceful degradation by using simple template-based
        generation without LLM assistance.
        
        Args:
            task_type: Task type to generate for
            context: Job context
            
        Returns:
            Optional[Dict]: Fallback prompt data or None
        """
        
        try:
            # Simple fallback template
            fallback_template = f"""
Task: {task_type}
Context: {context}

Please process the data according to the task requirements.
"""
            
            return {
                "prompt_text": fallback_template,
                "input_variables": ["data_context"],
                "expected_output": "text",
                "model_preference": "gpt-3.5-turbo",
                "max_tokens": 500,
                "temperature": 0.3,
                "llm_used": False
            }
            
        except Exception:
            return None
    
    def _should_use_llm(self, task_type: str, context: Dict[str, Any]) -> bool:
        """
        Determine if LLM assistance is needed for this task.
        
        Args:
            task_type: Task type to check
            context: Job context
            
        Returns:
            bool: True if LLM assistance is needed
        """
        
        # Default implementation - subclasses can override
        return self._requires_llm
    
    def _generate_with_llm(self, task_type: str, context: Dict[str, Any], 
                          langchain_manager: Any, job_id: str) -> Dict[str, Any]:
        """
        Generate prompt content using LLM assistance via LangChain.
        
        This method uses the LangChain integration to call the Relayer Gateway
        for dynamic prompt generation or enhancement.
        
        Args:
            task_type: Task type being generated
            context: Job context and parameters
            langchain_manager: Manager for LLM calls
            job_id: Job ID for logging
            
        Returns:
            Dict[str, Any]: LLM-generated content and metadata
        """
        
        logger.info(f"[{job_id}] Calling LLM for Sidekick '{self.name}' task '{task_type}'")
        
        # Create a meta-prompt to generate the actual prompt
        meta_prompt = self._create_meta_prompt(task_type, context)
        
        # Call the Relayer Gateway via LangChain Manager
        llm_response = langchain_manager.call_llm(
            prompt_text=meta_prompt,
            task_type=f"meta_generation_{task_type}",
            sidekick_name=self.name,
            job_id=job_id,
            model_preference=self._get_model_preference(task_type),
            temperature=0.3  # Lower temperature for consistent generation
        )
        
        return {
            "llm_content": llm_response.get("llm_output", ""),
            "model_used": llm_response.get("model_used"),
            "success": llm_response.get("success", False)
        }
    
    def _create_meta_prompt(self, task_type: str, context: Dict[str, Any]) -> str:
        """
        Create a meta-prompt for LLM-assisted prompt generation.
        
        This prompt instructs the LLM to generate or enhance the actual
        prompt template for the specified task.
        
        Args:
            task_type: Task type to create meta-prompt for
            context: Job context
            
        Returns:
            str: Meta-prompt for LLM
        """
        
        # Base meta-prompt template - subclasses can override
        return f"""
You are helping to generate a prompt template for a task of type '{task_type}'.

Task Context:
{context}

Please generate a clear, effective prompt template that will help an LLM perform this task.
The prompt should be specific, actionable, and include placeholders for variables that will be filled at runtime.

Return only the prompt template text, no additional explanation.
"""
    
    def _get_expected_output(self, task_type: str) -> str:
        """Get expected output format for task type."""
        return "structured_text"
    
    def _get_model_preference(self, task_type: str) -> str:
        """Get preferred model for task type."""
        return "gpt-4"
    
    def _get_temperature(self, task_type: str) -> float:
        """Get temperature setting for task type."""
        return 0.7
    
    def _get_max_tokens(self, task_type: str) -> int:
        """Get max tokens for task type."""
        return 1000
    
    def get_stats(self) -> Dict[str, int]:
        """Get statistics for this Sidekick."""
        return self._stats.copy()