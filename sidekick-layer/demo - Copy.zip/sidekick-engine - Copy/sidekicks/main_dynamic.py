"""
Dynamic FixxySidekick Azure Deployment Package
Complete deployment setup for production-ready dynamic prompt system
"""

# ----------------------------------------
# Azure Function App Integration
# ----------------------------------------

# main.py - Azure Function entry point
import azure.functions as func
import logging
import json
import os
from datetime import datetime
from pydantic import ValidationError

# Import the dynamic FixxySidekick components
from dynamic_fixxy import DynamicFixxySidekick, FixxyPromptStore, CosmosFixxyPromptStore
from models import SidekickRequest, SidekickResponse, SidekickEngineError
from clarity_secrets import get_secret

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global initialization
_dynamic_fixxy = None
_prompt_store = None

async def initialize_dynamic_fixxy():
    """Initialize Dynamic FixxySidekick with Azure services"""
    global _dynamic_fixxy, _prompt_store
    
    if _dynamic_fixxy is None:
        try:
            # Get configuration from environment and Key Vault
            cosmos_connection = get_secret("cosmos-db-connection-string")
            relayer_gateway_url = os.getenv("RELAYER_SIDEKICK_GATEWAY_URL")
            auth_token = get_secret("sidekick-layer--relayer-gateway-token")
            
            # Initialize prompt store (CosmosDB in production, in-memory for demo)
            if cosmos_connection:
                _prompt_store = CosmosFixxyPromptStore(cosmos_connection)
                logger.info("[INIT] Using CosmosDB prompt store")
            else:
                _prompt_store = FixxyPromptStore()
                logger.info("[INIT] Using in-memory prompt store")
            
            # Initialize Dynamic FixxySidekick
            _dynamic_fixxy = DynamicFixxySidekick(_prompt_store, relayer_gateway_url, auth_token)
            
            # Run initial migration if needed
            from dynamic_fixxy import FixxyPromptMigrator
            migrator = FixxyPromptMigrator(_prompt_store)
            await migrator.migrate_hardcoded_prompts()
            
            logger.info("[INIT] Dynamic FixxySidekick initialized successfully")
            
        except Exception as e:
            logger.error(f"[INIT] Failed to initialize Dynamic FixxySidekick: {str(e)}")
            raise
        # ADD after existing environment loading:
try:
    # Database configuration
    COSMOS_DB_CONNECTION_STRING = get_secret("cosmos-db-connection-string")
    COSMOS_DB_DATABASE_NAME = os.getenv("COSMOS_DB_DATABASE_NAME", "clarity-core-dev-logic-db")
    COSMOS_DB_CONTAINER_NAME = os.getenv("COSMOS_DB_CONTAINER_NAME", "stored-prompts")
    
    # Relayer Gateway configuration
    RELAYER_SIDEKICK_GATEWAY_URL = os.getenv("RELAYER_SIDEKICK_GATEWAY_URL")
    if not RELAYER_SIDEKICK_GATEWAY_URL:
        raise ValueError("RELAYER_SIDEKICK_GATEWAY_URL environment variable not set")
    
    logger.info("All environment variables loaded successfully")
    
except Exception as e:
    logger.error(f"Environment configuration error: {e}")
    raise
async def main(req: func.HttpRequest) -> func.HttpResponse:
    """Azure Function main entry point"""
    
    request_start_time = datetime.utcnow()
    job_id = None
    
    try:
        # Initialize if not already done
        await initialize_dynamic_fixxy()
        
        # Validate authentication
        auth_token = req.headers.get("x-internal-token")
        expected_token = get_secret("sidekick-layer--engine-token")
        
        if auth_token != expected_token:
            logger.warning("[AUTH] Invalid authentication token")
            return func.HttpResponse(
                json.dumps({
                    "status": "error",
                    "error_code": "AUTH_TOKEN_INVALID",
                    "error_message": "Invalid authentication token"
                }),
                status_code=401,
                mimetype="application/json"
            )
        
        # Parse and validate request
        try:
            request_body = req.get_json()
            validated_request = SidekickRequest(**request_body)
            job_id = validated_request.job_id
            
        except ValidationError as ve:
            logger.warning(f"[VALIDATION] Request validation failed: {ve}")
            return func.HttpResponse(
                json.dumps({
                    "status": "error",
                    "error_code": "REQUEST_VALIDATION_FAILED",
                    "error_message": "Request validation failed",
                    "details": ve.errors()
                }),
                status_code=400,
                mimetype="application/json"
            )
        except Exception as e:
            logger.error(f"[PARSING] Failed to parse request: {str(e)}")
            return func.HttpResponse(
                json.dumps({
                    "status": "error",
                    "error_code": "INVALID_JSON_FORMAT",
                    "error_message": "Invalid JSON format"
                }),
                status_code=400,
                mimetype="application/json"
            )
        
        logger.info(f"[{job_id}] Processing Dynamic FixxySidekick request: {validated_request.task_type}")
        
        # Validate Sidekick name
        if validated_request.sidekick_name != "fixxy":
            return func.HttpResponse(
                json.dumps({
                    "status": "error",
                    "error_code": "SIDEKICK_NOT_FOUND",
                    "error_message": f"Sidekick '{validated_request.sidekick_name}' not supported by this endpoint",
                    "job_id": job_id
                }),
                status_code=400,
                mimetype="application/json"
            )
        
        # Validate task type
        if validated_request.task_type not in _dynamic_fixxy.get_supported_tasks():
            return func.HttpResponse(
                json.dumps({
                    "status": "error",
                    "error_code": "TASK_TYPE_UNSUPPORTED",
                    "error_message": f"Task type '{validated_request.task_type}' not supported",
                    "job_id": job_id
                }),
                status_code=400,
                mimetype="application/json"
            )
        
        # Execute dynamic prompt generation
        try:
            prompt_result = await _dynamic_fixxy.create_prompt_template(
                validated_request.task_type,
                validated_request.job_context
            )
            
            execution_time = (datetime.utcnow() - request_start_time).total_seconds()
            
            # Build successful response
            response = SidekickResponse(
                status="success",
                request_id=validated_request.request_id,
                job_id=validated_request.job_id,
                sidekick_name=validated_request.sidekick_name,
                task_type=validated_request.task_type,
                prompt_template=prompt_result["prompt_template"],
                input_variables=prompt_result["input_variables"],
                execution_config={
                    "temperature": 0.3,
                    "max_tokens": 2000,
                    "top_p": 0.9
                },
                task_metadata={
                    "source": prompt_result["source"],
                    "prompt_id": prompt_result.get("prompt_id"),
                    "context_match_score": prompt_result["context_match_score"],
                    "quality_prediction": prompt_result["quality_prediction"],
                    "usage_count": prompt_result["usage_count"],
                    "success_rate": prompt_result["success_rate"],
                    "complexity_assessment": "dynamic",
                    "execution_time": execution_time,
                    "cache_performance": {
                        "cache_hit": prompt_result["source"] in ["exact_match", "similar_match"],
                        "generation_required": prompt_result["source"] == "generated"
                    }
                },
                sidekick_info={
                    "name": _dynamic_fixxy.name,
                    "version": _dynamic_fixxy.version,
                    "display_name": _dynamic_fixxy.display_name,
                    "capabilities": _dynamic_fixxy.get_supported_tasks(),
                    "performance_stats": _dynamic_fixxy.get_performance_stats()
                }
            )
            
            logger.info(f"[{job_id}] Successfully processed request in {execution_time:.2f}s "
                       f"(source: {prompt_result['source']}, quality: {prompt_result['quality_prediction']:.2f})")
            
            return func.HttpResponse(
                response.json(),
                status_code=200,
                mimetype="application/json"
            )
            
        except Exception as e:
            execution_time = (datetime.utcnow() - request_start_time).total_seconds()
            logger.error(f"[{job_id}] Prompt generation failed: {str(e)}", exc_info=True)
            
            # Return error response
            error_response = SidekickEngineError(
                error_code="TEMPLATE_GENERATION_FAILED",
                error_message="Failed to generate prompt template",
                error_category="processing",
                job_id=job_id,
                request_id=validated_request.request_id,
                timestamp=datetime.utcnow().isoformat(),
                details={"execution_time": execution_time},
                suggested_action="Retry with simplified context or contact support"
            )
            
            return func.HttpResponse(
                error_response.json(),
                status_code=500,
                mimetype="application/json"
            )
    
    except Exception as e:
        execution_time = (datetime.utcnow() - request_start_time).total_seconds()
        logger.error(f"[{job_id or 'UNKNOWN'}] Unexpected error: {str(e)}", exc_info=True)
        
        # Return generic error response
        error_response = SidekickEngineError(
            error_code="INTERNAL_SERVER_ERROR",
            error_message="An unexpected internal error occurred",
            error_category="internal",
            job_id=job_id,
            timestamp=datetime.utcnow().isoformat(),
            details={"execution_time": execution_time},
            suggested_action="Retry request or contact support if problem persists"
        )
        
        return func.HttpResponse(
            error_response.json(),
            status_code=500,
            mimetype="application/json"
        )


