"""
Sidekick Engine Package Initializer

This package contains the complete Sidekick Engine implementation
for the Clarity byDisrupt platform. The engine manages all 10 Sidekicks
across Data, Ops, and Support crews using LangChain integration.

Integration Points:
- Called by: Sidekick Router (expects SidekickEngineRequest format)
- Calls to: Relayer Gateway (when LLM assistance needed)
- Returns: SidekickEngineResponse (must match Router expectations)
- Config: Loads Sidekick registry and LangChain components
- Logging: Uses [job_id] format for traceability
- Secrets: Uses clarity_secrets.get_secret() pattern

Azure Functions Entry Point:
- main.py contains the Azure Function handler
- All components are Azure Functions compatible
- Uses managed identity for Key Vault access
"""

from .main import main

__all__ = ['main']