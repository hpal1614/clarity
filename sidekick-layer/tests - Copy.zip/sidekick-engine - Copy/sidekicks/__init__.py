"""
Dynamic Sidekicks Package
"""

from .dynamic_fixxy import DynamicFixxySidekick

# Sidekick registry for easy access
SIDEKICK_REGISTRY = {
    "fixxy": DynamicFixxySidekick,
}

__all__ = [
    "DynamicFixxySidekick",
    "SIDEKICK_REGISTRY"
]